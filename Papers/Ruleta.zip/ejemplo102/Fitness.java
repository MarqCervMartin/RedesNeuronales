package ejemplo102;

public class Fitness {

    static String objetivo = "Hola mundo";

    static public double evaluate(Chromosome individuo) {
        double aptitud = 0;
        //Calcular aptitud.
        
        return aptitud;
    }

}
