package ejemplo102;

import java.util.ArrayList;
import java.util.Random;

public class SeleccionRuleta {

    private int tamPoblacion = 0;//N
    private double frecuenciaEsperadaTotal = 0;//f
    private double[] aptitudes;
    private double[] valoresEsperados;//Ve
    private double r;//Numero pseudoAleatorio
    private java.util.Random random;
    private ArrayList<Integer> indicesElegidos = new ArrayList();

    public SeleccionRuleta(double[] aptitudes, Random random) {
        this.aptitudes = aptitudes;
        this.random = random;
    }

    public ArrayList<Integer> selection() {
        //Implementar ruleta.
        
        return indicesElegidos;
    }

    /**
     * @return the tamPoblacion
     */
    public int getTamPoblacion() {
        return tamPoblacion;
    }

    /**
     * @param tamPoblacion the tamPoblacion to set
     */
    public void setTamPoblacion(int tamPoblacion) {
        this.tamPoblacion = tamPoblacion;
    }

    /**
     * @return the frecuenciaEsperadaTotal
     */
    public double getFrecuenciaEsperadaTotal() {
        return frecuenciaEsperadaTotal;
    }

    /**
     * @param frecuenciaEsperadaTotal the frecuenciaEsperadaTotal to set
     */
    public void setFrecuenciaEsperadaTotal(double frecuenciaEsperadaTotal) {
        this.frecuenciaEsperadaTotal = frecuenciaEsperadaTotal;
    }

    /**
     * @return the aptitudes
     */
    public double[] getAptitudes() {
        return aptitudes;
    }

    /**
     * @param aptitudes the aptitudes to set
     */
    public void setAptitudes(double[] aptitudes) {
        this.aptitudes = aptitudes;
    }

    /**
     * @return the valoresEsperados
     */
    public double[] getValoresEsperados() {
        return valoresEsperados;
    }

    /**
     * @param valoresEsperados the valoresEsperados to set
     */
    public void setValoresEsperados(double[] valoresEsperados) {
        this.valoresEsperados = valoresEsperados;
    }

    /**
     * @return the r
     */
    public double getR() {
        return r;
    }

    /**
     * @param r the r to set
     */
    public void setR(double r) {
        this.r = r;
    }

    /**
     * @return the random
     */
    public java.util.Random getRandom() {
        return random;
    }

    /**
     * @param random the random to set
     */
    public void setRandom(java.util.Random random) {
        this.random = random;
    }

    /**
     * @return the indicesElegidos
     */
    public ArrayList<Integer> getIndicesElegidos() {
        return indicesElegidos;
    }

    /**
     * @param indicesElegidos the indicesElegidos to set
     */
    public void setIndicesElegidos(ArrayList<Integer> indicesElegidos) {
        this.indicesElegidos = indicesElegidos;
    }
}
