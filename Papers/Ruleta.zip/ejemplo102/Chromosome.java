package ejemplo102;

import java.util.Arrays;
import java.util.Random;

public class Chromosome {

    private String cromo;
    static private int totalGenes;
    static private String alfabeto;
    static private Random random;

    @Override
    public String toString() {
        return cromo;
    }

    public void inicializa() {
        cromo = "";
        for (int i = 0; i < totalGenes; i++) {
            int idx = random.nextInt(alfabeto.length());
            cromo = cromo + alfabeto.charAt(idx);
        }
    }

    public String getCromo() {
        return cromo;
    }

    public void setCromo(String cromo) {
        this.cromo = cromo;
    }

    public int getTotalGenes() {
        return totalGenes;
    }

    public void setTotalGenes(int totalGenes) {
        Chromosome.totalGenes = totalGenes;
    }

    public String getAlfabeto() {
        return alfabeto;
    }

    public void setAlfabeto(String alfabeto) {
        Chromosome.alfabeto = alfabeto;
    }

    public Random getRandom() {
        return random;
    }

    public void setRandom(Random random) {
        Chromosome.random = random;
    }

    public void mutar() {
        int mutarGen = random.nextInt(cromo.length());
        int letra = random.nextInt(alfabeto.length());
        String mutado = "";
        for (int i = 0; i < cromo.length(); i++) {
            if (i == mutarGen) {
                mutado += alfabeto.charAt(letra);
            } else {
                mutado += cromo.charAt(i);
            }
        }
        cromo = mutado;
    }

    public Chromosome[] cruza(Chromosome otro) {
        Chromosome[] hijos = new Chromosome[2];
        //Implementar cruza
        return hijos;

    }

    public static void main(String[] args) {
        Chromosome c = new Chromosome();
        c.setAlfabeto("abcdefghijklmnopqrstuvxwyzABCDEFGHIJKLMNOPQRSTUVWXYZ ");
        c.setRandom(new Random(System.currentTimeMillis()));
        c.setTotalGenes(10);
        c.inicializa();
        System.out.println(c);
        System.out.println(Fitness.evaluate(c));
        Chromosome c2 = new Chromosome();
        c2.inicializa();
        System.out.println(c2);
        System.out.println(Fitness.evaluate(c2));
        
        

    }

}
